KarthikOfficial Personal Locker

Open index.html in a browser to use the website.

Features:
- Documents folder
- Gaming Setup folder
- Ideas folder
- Important Words folder
- Add, edit and delete saved items
- Search from the home page
- Responsive design
- Data saved locally in the browser via localStorage

Important:
This version is a front-end prototype. Data is stored only in the browser/device where it is used. It is not a cloud backup or secure password manager.
